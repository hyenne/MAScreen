var http = require('http');
var fs = require('fs');
 
var server = http.createServer();
 
server.listen(7070, function() {
    console.log('server start');
});
 
server.on('request', function(req, res) {
 
    fs.readFile('./stt.txt', function(err, data) {
        res.writeHead(200, {"Content-Type": "text/plain"});
        res.write(data);
        res.end();
    });
});